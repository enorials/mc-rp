#version 150

#moj_import <fog.glsl>
#moj_import <light.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat3 IViewRotMat;
uniform vec2 ScreenSize;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
out float minimap;
out float minimapShape;
out float keepEdges;
out float frameStyle;
out float frameThickness;
out float colorProfile;
out float transition;
out float fullscreenMinimap;
out float sx, sy;

#define EH_VERSION 4
#define EH_OFFSET 29

float get_id(float offset) {
    if (offset <= 0.0) return 0.0;
    return trunc(offset / 1000.0);
}

#moj_import <minimap/vertex_util.glsl>

void main() {
    vec3 pos = Position;

    vec2 pixel = vec2(ProjMat[0][0], ProjMat[1][1]) / 2.0;
    int guiScale = int(round(pixel.x / (1.0 / ScreenSize.x)));
    vec2 guiSize = ScreenSize / guiScale;

    float id = get_id((round(EH_OFFSET - Position.y)) * -1.0);

    if (id > 99.0 && Color.a != 0.0) {
        float yOffset = 0.0;
        float xOffset = 0.0;
        float layer = 0.0;
        vec2 scale = vec2(1.0, 1.0);
        bool outlined = false;

        switch (int(id)) {
            case 100:
                xOffset = int(guiSize.x * (-7.0/100))-53;
                yOffset = int(guiSize.y * (1.0/100))+10;
                layer = 0.0;
                outlined = true;
                break;
            case 101:
                xOffset = int(guiSize.x * (-7.0/100))-69;
                yOffset = int(guiSize.y * (1.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 102:
                xOffset = int(guiSize.x * (-0.0/100))-94;
                yOffset = int(guiSize.y * (100.0/100))-70;
                layer = 0.0;
                break;
            case 103:
                xOffset = int(guiSize.x * (-0.0/100))-131;
                yOffset = int(guiSize.y * (100.0/100))-120;
                layer = 0.0;
                outlined = true;
                break;
            case 104:
                xOffset = int(guiSize.x * (-50.0/100))-3;
                yOffset = int(guiSize.y * (0.0/100))+44;
                layer = 0.0;
                break;
            case 105:
                xOffset = int(guiSize.x * (-50.0/100));
                yOffset = int(guiSize.y * (0.0/100))+44;
                layer = 8.0;
                outlined = true;
                break;
            case 106:
                xOffset = int(guiSize.x * (-0.3/100))-72;
                yOffset = int(guiSize.y * (100.0/100))-53;
                layer = 0.0;
                break;
            case 107:
                xOffset = int(guiSize.x * (-0.0/100))-234;
                yOffset = int(guiSize.y * (100.0/100))-81;
                layer = 8.0;
                outlined = true;
                break;
            case 108:
                xOffset = int(guiSize.x * (-0.3/100))-276;
                yOffset = int(guiSize.y * (100.0/100))-58;
                layer = 0.0;
                break;
            case 109:
                xOffset = int(guiSize.x * (-0.0/100))-245;
                yOffset = int(guiSize.y * (100.0/100))-60;
                layer = 8.0;
                outlined = true;
                break;
            case 110:
                xOffset = int(guiSize.x * (-0.0/100))-269;
                yOffset = int(guiSize.y * (100.0/100))-81;
                layer = 0.0;
                break;
            case 111:
                xOffset = int(guiSize.x * (-0.0/100))-275;
                yOffset = int(guiSize.y * (100.0/100))-71;
                layer = 0.0;
                break;
            case 112:
                xOffset = int(guiSize.x * (-0.0/100))-243;
                yOffset = int(guiSize.y * (100.0/100))-71;
                layer = 8.0;
                outlined = true;
                break;
            case 113:
                xOffset = int(guiSize.x * (-0.3/100))-225;
                yOffset = int(guiSize.y * (100.0/100))-43;
                layer = 0.0;
                break;
            case 114:
                xOffset = int(guiSize.x * (-48.0/100))-8;
                yOffset = int(guiSize.y * (95.0/100))+3;
                layer = 0.0;
                outlined = true;
                break;
            case 115:
                xOffset = int(guiSize.x * (-94.0/100))-55;
                yOffset = int(guiSize.y * (95.0/100))-12;
                layer = 0.0;
                break;
            case 116:
                xOffset = int(guiSize.x * (-94.0/100))-55;
                yOffset = int(guiSize.y * (95.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 117:
                xOffset = int(guiSize.x * (-50.0/100))-18;
                yOffset = int(guiSize.y * (89.0/100))-24;
                layer = 0.0;
                outlined = true;
                break;
            case 118:
                xOffset = int(guiSize.x * (-50.0/100))-18;
                yOffset = int(guiSize.y * (89.0/100))-12;
                layer = 6.0;
                break;
            case 119:
                xOffset = int(guiSize.x * (-50.0/100))-18;
                yOffset = int(guiSize.y * (89.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 120:
                xOffset = int(guiSize.x * (-50.0/100))-2;
                yOffset = int(guiSize.y * (89.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 121:
                xOffset = int(guiSize.x * (-50.0/100))-2;
                yOffset = int(guiSize.y * (89.0/100))-12;
                layer = 6.0;
                break;
            case 122:
                xOffset = int(guiSize.x * (-50.0/100))-2;
                yOffset = int(guiSize.y * (89.0/100))-12;
                layer = 10.0;
                outlined = true;
                break;
            case 123:
                xOffset = int(guiSize.x * (-0.0/100))-170;
                yOffset = int(guiSize.y * (100.0/100))-43;
                layer = 0.0;
                break;
            case 124:
                xOffset = int(guiSize.x * (-0.0/100))-17;
                yOffset = int(guiSize.y * (100.0/100))-53;
                layer = 0.0;
                break;
            case 125:
                xOffset = int(guiSize.x * (-0.0/100))-222;
                yOffset = int(guiSize.y * (100.0/100))-58;
                layer = 0.0;
                break;
            case 126:
                xOffset = int(guiSize.x * (-0.0/100))-114;
                yOffset = int(guiSize.y * (100.0/100))-60;
                layer = 8.0;
                outlined = true;
                break;
            case 127:
                xOffset = int(guiSize.x * (-0.0/100))-227;
                yOffset = int(guiSize.y * (100.0/100))-71;
                layer = 0.0;
                break;
            case 128:
                xOffset = int(guiSize.x * (-0.0/100))-127;
                yOffset = int(guiSize.y * (100.0/100))-71;
                layer = 8.0;
                outlined = true;
                break;
            case 129:
                xOffset = int(guiSize.x * (-0.0/100))-235;
                yOffset = int(guiSize.y * (100.0/100))-81;
                layer = 0.0;
                break;
            case 130:
                xOffset = int(guiSize.x * (-0.0/100))-127;
                yOffset = int(guiSize.y * (100.0/100))-81;
                layer = 8.0;
                outlined = true;
                break;
            case 131:
                xOffset = int(guiSize.x * (-47.0/100));
                yOffset = int(guiSize.y * (96.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 132:
                xOffset = int(guiSize.x * (-75.0/100));
                yOffset = int(guiSize.y * (96.0/100))-12;
                layer = 0.0;
                break;
            case 133:
                xOffset = int(guiSize.x * (-75.0/100));
                yOffset = int(guiSize.y * (96.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 134:
                xOffset = int(guiSize.x * (-84.5/100));
                yOffset = int(guiSize.y * (100.0/100))-30;
                layer = 0.0;
                outlined = true;
                break;
            case 135:
                xOffset = int(guiSize.x * (-10.0/100));
                yOffset = int(guiSize.y * (1.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 136:
                xOffset = int(guiSize.x * (-10.0/100))+16;
                yOffset = int(guiSize.y * (1.0/100))+10;
                layer = 0.0;
                outlined = true;
                break;
            case 137:
                xOffset = int(guiSize.x * (-0.0/100))-151;
                yOffset = int(guiSize.y * (100.0/100))-70;
                layer = 0.0;
                break;
            case 138:
                xOffset = int(guiSize.x * (-0.0/100))-139;
                yOffset = int(guiSize.y * (100.0/100))-120;
                layer = 0.0;
                outlined = true;
                break;
            case 139:
                xOffset = int(guiSize.x * (-94.0/100));
                yOffset = int(guiSize.y * (7.0/100));
                layer = 0.0;
                break;
            case 140:
                xOffset = int(guiSize.x * (-96.6/100))-90;
                yOffset = int(guiSize.y * (7.0/100))-17;
                layer = 4.0;
                break;
            case 141:
                xOffset = int(guiSize.x * (-98.9/100))-118;
                yOffset = int(guiSize.y * (7.0/100))-17;
                layer = 4.0;
                break;
            case 142:
                xOffset = int(guiSize.x * (-101.3/100))-146;
                yOffset = int(guiSize.y * (7.0/100))-17;
                layer = 4.0;
                break;        }

        if ((Position.z != 0.0 && Position.z != -90.0) || outlined) {
            pos.y -= (id * 1000.0) + 500.0 + EH_OFFSET;
            pos.x -= (guiSize.x * 0.5);

            pos.x *= scale.x;
            pos.y *= scale.y;

            pos.y += guiSize.y;
            if (guiScale == 3) {
                pos.x += 1.45;
            }

            pos -= vec3(xOffset, yOffset, 0.0);
            pos.z += layer;
        }
    }    vec4 vertex = vec4(pos, 1.0);
    vec4 vcolor = Color * texelFetch(Sampler2, UV2 / 16, 0);

    gl_Position = ProjMat * ModelViewMat * vertex;
    vertexDistance = fog_distance(ModelViewMat, IViewRotMat * pos, FogShape);

    #moj_import <minimap/vertex_main.glsl>
}
