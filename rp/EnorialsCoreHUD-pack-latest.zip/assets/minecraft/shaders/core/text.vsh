#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;
out vec2 texCoord1;
out vec2 texCoord2;
out float minimap;
out float minimapShape;
out float keepEdges;
out float frameStyle;
out float frameThickness;
out float colorProfile;
out float transition;
out float fullscreenMinimap;
out float sx;
out float sy;
#moj_import <minecraft:minimap/vertex_util.glsl>
#define EH_VERSION 4
#define EH_OFFSET 29

float get_id(float offset) {
    if (offset <= 0.0) return 0.0;
    return trunc(offset / 1000.0);
}


void main() {
    vec3 pos = Position;
#ifdef IS_GUI


    vec2 pixel = vec2(ProjMat[0][0], ProjMat[1][1]) / 2.0;
    int guiScale = max(1, int(round(pixel.x * ScreenSize.x)));
    vec2 guiSize = ScreenSize / guiScale;

    float id = get_id((round(EH_OFFSET - Position.y)) * -1.0);

    if (id > 99.0 && Color.a != 0.0) {
        float yOffset = 0.0;
        float xOffset = 0.0;
        float layer = 0.0;
        vec2 scale = vec2(1.0, 1.0);
        bool outlined = false;

        switch (int(id)) {
            case 100:
                xOffset = int(guiSize.x * (-7.0/100))-53;
                yOffset = int(guiSize.y * (1.0/100))+10;
                layer = 0.0;
                outlined = true;
                break;
            case 101:
                xOffset = int(guiSize.x * (-7.0/100))-69;
                yOffset = int(guiSize.y * (1.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 102:
                xOffset = int(guiSize.x * (-0.0/100))-94;
                yOffset = int(guiSize.y * (100.0/100))-70;
                layer = 0.0;
                break;
            case 103:
                xOffset = int(guiSize.x * (-0.0/100))-131;
                yOffset = int(guiSize.y * (100.0/100))-120;
                layer = 0.0;
                outlined = true;
                break;
            case 104:
                xOffset = int(guiSize.x * (-50.0/100))-3;
                yOffset = int(guiSize.y * (0.0/100))+44;
                layer = 0.0;
                break;
            case 105:
                xOffset = int(guiSize.x * (-50.0/100));
                yOffset = int(guiSize.y * (0.0/100))+44;
                layer = 8.0;
                outlined = true;
                break;
            case 106:
                xOffset = int(guiSize.x * (-0.3/100))-72;
                yOffset = int(guiSize.y * (100.0/100))-53;
                layer = 0.0;
                break;
            case 107:
                xOffset = int(guiSize.x * (-0.0/100))-234;
                yOffset = int(guiSize.y * (100.0/100))-81;
                layer = 8.0;
                outlined = true;
                break;
            case 108:
                xOffset = int(guiSize.x * (-0.3/100))-276;
                yOffset = int(guiSize.y * (100.0/100))-58;
                layer = 0.0;
                break;
            case 109:
                xOffset = int(guiSize.x * (-0.0/100))-245;
                yOffset = int(guiSize.y * (100.0/100))-60;
                layer = 8.0;
                outlined = true;
                break;
            case 110:
                xOffset = int(guiSize.x * (-0.0/100))-269;
                yOffset = int(guiSize.y * (100.0/100))-81;
                layer = 0.0;
                break;
            case 111:
                xOffset = int(guiSize.x * (-0.3/100))-269;
                yOffset = int(guiSize.y * (100.0/100))-71;
                layer = 0.0;
                break;
            case 112:
                xOffset = int(guiSize.x * (-0.3/100))-237;
                yOffset = int(guiSize.y * (100.0/100))-71;
                layer = 8.0;
                outlined = true;
                break;
            case 113:
                xOffset = int(guiSize.x * (-0.3/100))-225;
                yOffset = int(guiSize.y * (100.0/100))-43;
                layer = 0.0;
                break;
            case 114:
                xOffset = int(guiSize.x * (-48.0/100))-8;
                yOffset = int(guiSize.y * (95.0/100))+3;
                layer = 0.0;
                outlined = true;
                break;
            case 115:
                xOffset = int(guiSize.x * (-94.0/100))-55;
                yOffset = int(guiSize.y * (95.0/100))-12;
                layer = 0.0;
                break;
            case 116:
                xOffset = int(guiSize.x * (-94.0/100))-55;
                yOffset = int(guiSize.y * (95.0/100));
                layer = 0.0;
                outlined = true;
                break;
            case 117:
                xOffset = int(guiSize.x * (-50.0/100))-18;
                yOffset = int(guiSize.y * (89.0/100))-24;
                layer = 0.0;
                outlined = true;
                break;
            case 118:
                xOffset = int(guiSize.x * (-50.0/100))-18;
                yOffset = int(guiSize.y * (89.0/100))-12;
                layer = 6.0;
                break;
            case 119:
                xOffset = int(guiSize.x * (-50.0/100))-18;
                yOffset = int(guiSize.y * (89.0/100));
                layer = 0.0;
                outlined = true;
                break;
        }

        if ((Position.z != 0.0 && Position.z != -90.0) || outlined) {
            pos.y -= (id * 1000.0) + 500.0 + EH_OFFSET;
            pos.x -= (guiSize.x * 0.5);

            pos.x *= scale.x;
            pos.y *= scale.y;

            pos.y += guiSize.y;
            if (guiScale == 3) {
                pos.x += 1.45;
            }

            pos -= vec3(xOffset, yOffset, 0.0);
            pos.z += layer;
        }
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    vec4 vcolor = vertexColor;
    #moj_import <minecraft:minimap/vertex_main.glsl>
}
