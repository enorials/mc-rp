// EnorialsCoreHUD preset v1
// Safe default: no color transform. Future presets can be enabled here.

vec4 eh_corehud_corner_preset(vec4 inputColor, vec2 uv, vec2 screenSize) {
    return inputColor;
}
