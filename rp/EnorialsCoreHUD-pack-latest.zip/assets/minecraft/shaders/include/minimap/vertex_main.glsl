fullscreenMinimap = 0.0;
transition = 0.0;
minimap = 0.0;
minimapShape = 0.0;
keepEdges = 0.0;
frameStyle = 0.0;
colorProfile = 0.0;
sx = 0.0;
sy = 0.0;
vec2 uv = UV0;
vec2 uv2 = vec2(0.0);

if (texture(Sampler0, uv).xyz == vec3(112. / 255., 108. / 255., 138. / 255.)) {
    int vertexId = gl_VertexID % 4;
    float ratio = ScreenSize.x / ScreenSize.y;
    float vratio = ScreenSize.y / ScreenSize.x;
    if (vratio < ratio) ratio = 1;
    else vratio = 1;
    int minimapSize = decodeUnsigned(25, 0);
    int minimapShapeRaw = decodeUnsigned(33, 0);
    int minimapFrameStyle = decodeUnsigned(41, 0);
    int minimapFrameThickness = decodeUnsigned(49, 0);
    int colorProfileRaw = decodeUnsigned(57, 0);
    frameStyle = float(minimapFrameStyle);
    frameThickness = float(minimapFrameThickness);
    colorProfile = float(colorProfileRaw);
    minimapShape = minimapShapeRaw > 0 ? 1.0 : 0.0;
    float minimapScale = 1.0;
    if (minimapSize == 0) {
        minimapScale = 0.52;
    } else if (minimapSize == 1) {
        minimapScale = 0.76;
    }
    float minimapMargin = 0.04;
    float minimapBaseWidth = 0.7 - minimapMargin;
    float minimapWidth = minimapBaseWidth * minimapScale;
    float minimapMax = minimapMargin + minimapWidth;
    switch (vertexId) {
        case 0: { gl_Position = vec4(-1 + minimapMargin * vratio, 1 - minimapMargin * ratio, 0, 1); uv2 = vec2(0, 1); break; }
        case 1: { gl_Position = vec4(-1 + minimapMargin * vratio, 1 - minimapMax * ratio, 0, 1); uv2 = vec2(0, 0); break; }
        case 2: { gl_Position = vec4(-1 + minimapMax * vratio, 1 - minimapMax * ratio, 0, 1); uv2 = vec2(1, 0); break; }
        case 3: { gl_Position = vec4(-1 + minimapMax * vratio, 1 - minimapMargin * ratio, 0, 1); uv2 = vec2(1, 1); break; }
    }

    float texel = 1. / 128.;
    bool rightSide = sign(length(texture(Sampler0, vec2(texel * 17., 0.)).xyz)) > 0;
    bool markerMeta = sign(length(texture(Sampler0, vec2(0., texel)).xyz)) > 0;
    int panelMagic = decodeUnsigned(1, 1);
    bool coordinatesPanel = markerMeta && panelMagic == 255;

    if (coordinatesPanel) {
        float panelGap = 0.015;
        float panelHeight = 0.16 * minimapScale;
        float panelTop = 1.0 - (minimapMax + panelGap) * ratio;
        float panelBottom = 1.0 - (minimapMax + panelGap + panelHeight) * ratio;
        switch (vertexId) {
            case 0: { gl_Position = vec4(-1 + minimapMargin * vratio, panelTop, 0, 1); uv2 = vec2(0, 1); break; }
            case 1: { gl_Position = vec4(-1 + minimapMargin * vratio, panelBottom, 0, 1); uv2 = vec2(0, 0); break; }
            case 2: { gl_Position = vec4(-1 + minimapMax * vratio, panelBottom, 0, 1); uv2 = vec2(1, 0); break; }
            case 3: { gl_Position = vec4(-1 + minimapMax * vratio, panelTop, 0, 1); uv2 = vec2(1, 1); break; }
        }
        if (rightSide) {
            gl_Position.x += 2.0 - (minimapMargin + minimapMax) * vratio;
        }
        minimap = 3.0;
        vcolor = Color;
        uv = UV0;
    } else {
        vec3 local = transpose(mat3(ModelViewMat)) * vec3(1, 0, 0);
        float yaw = -atan(local.x, local.z);

        float vx = decodeFixedPoint(1, 0);
        float vz = decodeFixedPoint(9, 0);
        int minimapZoom = decodeUnsigned(65, 0);
        float zoomScale = minimapZoom > 0 ? 2.0 : 1.0;

        uv -= vec2(0.5);
        uv = uv * mat2_rotate_z(yaw);
        uv /= zoomScale;
        uv += vec2(0.5);

        minimap = 1.0;
        vcolor = Color;
        uv += vec2(texel) * vec2(-vx, -vz);

        if (rightSide) {
            gl_Position.x += 2.0 - (minimapMargin + minimapMax) * vratio;
        }

        bool isMarker = sign(length(texture(Sampler0, vec2(0., texel)).xyz)) > 0;
        if (isMarker) {
            float depth = decodeFixedPoint(1, 1);
            gl_Position.z -= depth;

            float rPointX = decodeFixedPoint(9, 1);
            float rPointZ = decodeFixedPoint(1, 2);
            vec2 rPoint = vec2(rPointZ, rPointX);
            uv -= rPoint;
                uv = uv * mat2_rotate_z(-yaw);
            uv += rPoint;

            if (sign(length(texture(Sampler0, vec2(0., texel * 2)).xyz)) == 0) {
                vcolor = vec4(0.0);
            }

            bool keep = sign(length(texture(Sampler0, vec2(texel * 9., texel * 2)).xyz)) > 0;
            keepEdges = keep ? 1.0 : 0.0;
            minimap = 2.0;
        }
    }
} else {
    int fullscreenMagic = decodeUnsigned(0, 0);
    if (fullscreenMagic == 178) {
        int segmentX = decodeUnsigned(8, 0);
        int segmentY = decodeUnsigned(16, 0);
        int xSegments = decodeUnsigned(24, 0);
        int ySegments = decodeUnsigned(32, 0);
        sx = float(segmentX) / float(xSegments - 1);
        sy = float(segmentY) / float(ySegments - 1);
        transition = decodeFixedPoint(40, 0);
        int vertexId = gl_VertexID % 4;
        float ratio = ScreenSize.x / ScreenSize.y;
        float vratio = ScreenSize.y / ScreenSize.x;
        if (vratio < ratio) ratio = 1;
        else vratio = 1;
        float left = -float(xSegments) * 0.5 * vratio * 0.64;
        float top = float(ySegments) * 0.5 * ratio * 0.64 - (1.0 - transition);
        switch (vertexId) {
            case 0: { gl_Position = vec4(left + 0.64 * segmentX * vratio,       top - 0.64 * segmentY * ratio,       -0.5, 1); uv2 = vec2(0, 1); break; }
            case 1: { gl_Position = vec4(left + 0.64 * segmentX * vratio,       top - 0.64 * (segmentY + 1) * ratio, -0.5, 1); uv2 = vec2(0, 0); break; }
            case 2: { gl_Position = vec4(left + 0.64 * (segmentX + 1) * vratio, top - 0.64 * (segmentY + 1) * ratio, -0.5, 1); uv2 = vec2(1, 0); break; }
            case 3: { gl_Position = vec4(left + 0.64 * (segmentX + 1) * vratio, top - 0.64 * segmentY * ratio,       -0.5, 1); uv2 = vec2(1, 1); break; }
        }
        vcolor = Color;
        fullscreenMinimap = 1.0;
    } else if (fullscreenMagic == 109) {
        transition = decodeFixedPoint(8, 0);
        int vertexId = gl_VertexID % 4;
        switch (vertexId) {
            case 0: { gl_Position = vec4(-1, 1, -0.4, 1); uv2 = vec2(0, 1); break; }
            case 1: { gl_Position = vec4(-1, -1, -0.4, 1); uv2 = vec2(0, 0); break; }
            case 2: { gl_Position = vec4(1, -1, -0.4, 1); uv2 = vec2(1, 0); break; }
            case 3: { gl_Position = vec4(1, 1, -0.4, 1); uv2 = vec2(1, 1); break; }
        }
        vcolor = Color;
        fullscreenMinimap = 2.0;
    }
}

texCoord0 = UV0;
texCoord1 = uv;
texCoord2 = uv2;
vertexColor = vcolor;
