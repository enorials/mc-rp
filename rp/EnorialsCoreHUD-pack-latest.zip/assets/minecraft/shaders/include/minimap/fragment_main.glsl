#define BORDER_COLOR1 vec4(vec3(40. / 255.), 1.)
#define BORDER_COLOR2 vec4(vec3(70. / 255.), 1.)

if (minimap == 3.0) {
    vec4 color = texture(Sampler0, texCoord1);
    remapColor(color, colorProfile);
    fragColor = color * vertexColor * ColorModulator;
    if (fract(texCoord1.y) < 3. / 128.) {
        discard;
    }
    if (fract(texCoord1.x) <= 1. / 128. || fract(texCoord1.x) >= 127. / 128.) {
        discard;
    }
    if (fragColor.a < 0.1) {
        discard;
    }
    return;
}

if (minimap == 1.0 || minimap == 2.0) {
    bool squareShape = minimapShape >= 0.5;
    vec2 uvn11 = texCoord2 * 2.0 - 1.0;
    float dist = dot(uvn11, uvn11);
    float edge = max(abs(uvn11.x), abs(uvn11.y));
    int style = int(mod(frameStyle + 0.5, 6.0));
    int thickness = int(mod(frameThickness + 0.5, 3.0));
    float borderMetric = squareShape ? edge : dist;

    float outerThreshold = 0.93;
    float borderWidth = 0.048;
    if (thickness == 0) {
        borderWidth = 0.032;
    } else if (thickness == 2) {
        borderWidth = 0.068;
    }
    float innerThreshold = outerThreshold - borderWidth;
    bool inside = borderMetric < innerThreshold;
    // Keep-edge layers should only extend a tiny bit beyond the map shape.
    // Prevents stray dots/artefacts outside the circular minimap.
    float edgeKeepThreshold = outerThreshold + (squareShape ? 0.02 : 0.075);
    bool edgeKeepVisible = keepEdges == 1.0 && borderMetric < edgeKeepThreshold;
    bool border = borderMetric < outerThreshold;
    if (inside || edgeKeepVisible) {
        bool invalidSample = texCoord1.x < 0.0 || texCoord1.y < 0.0 || texCoord1.x >= 1.0 || texCoord1.y >= 1.0 ||
            (texCoord1.x < 17. / 128. && texCoord1.y < 3. / 128.) ||
            texCoord1.x <= 1. / 128. || texCoord1.x >= 127. / 128. || texCoord1.y >= 127. / 128.;
        if (invalidSample) {
            discard;
        }
        vec4 color = texture(Sampler0, texCoord1);
        remapColor(color, colorProfile);
        fragColor = color * vertexColor * ColorModulator;
    } else if (border && minimap == 1.0) {
        vec4 borderBase = vec4(17. / 255., 17. / 255., 17. / 255., 1.0);
        vec4 borderBandA = vec4(40. / 255., 40. / 255., 40. / 255., 1.0);
        vec4 borderBandB = vec4(70. / 255., 70. / 255., 70. / 255., 1.0);
        float ring = clamp((borderMetric - innerThreshold) / max(0.0001, borderWidth), 0.0, 1.0);
        float angle = atan(uvn11.y, uvn11.x);
        const float PI = 3.14159265359;
        const float TAU = 6.28318530718;

        if (style == 1) {
            borderBase = vec4(10. / 255., 24. / 255., 40. / 255., 1.0);
            borderBandA = vec4(35. / 255., 111. / 255., 168. / 255., 1.0);
            borderBandB = vec4(128. / 255., 218. / 255., 250. / 255., 1.0);
            float wave = 0.5 + 0.5 * sin(angle * 8.0 + ring * 26.0);
            fragColor = mix(borderBase, borderBandA, ring);
            fragColor = mix(fragColor, borderBandB, wave * (0.35 + 0.35 * ring));
        } else if (style == 2) {
            borderBase = vec4(28. / 255., 20. / 255., 10. / 255., 1.0);
            borderBandA = vec4(145. / 255., 104. / 255., 27. / 255., 1.0);
            borderBandB = vec4(242. / 255., 206. / 255., 95. / 255., 1.0);
            fragColor = mix(borderBase, borderBandA, ring);
            float cornerAccent = squareShape ? smoothstep(0.55, 0.82, abs(uvn11.x) * abs(uvn11.y)) : 0.0;
            float spoke = abs(fract((angle + PI) / TAU * 12.0) - 0.5);
            float radialAccent = squareShape ? 0.0 : 1.0 - smoothstep(0.38, 0.50, spoke);
            float accent = max(cornerAccent, radialAccent * (1.0 - ring));
            fragColor = mix(fragColor, borderBandB, clamp(accent, 0.0, 1.0));
            if (ring > 0.78) {
                fragColor = mix(fragColor, borderBase, 0.45);
            }
        } else if (style == 3) {
            borderBase = vec4(8. / 255., 26. / 255., 17. / 255., 1.0);
            borderBandA = vec4(28. / 255., 134. / 255., 82. / 255., 1.0);
            borderBandB = vec4(165. / 255., 248. / 255., 178. / 255., 1.0);
            fragColor = mix(borderBase, borderBandA, ring);

            float sectors = 16.0;
            float sector = fract((angle + PI) / TAU * sectors);
            float facetEdge = min(sector, 1.0 - sector);
            float facet = 1.0 - smoothstep(0.08, 0.28, facetEdge);
            float radialFacet = 1.0 - smoothstep(0.30, 0.95, abs(uvn11.x * uvn11.y));
            float crystalMix = clamp(0.55 * facet + 0.65 * radialFacet, 0.0, 1.0);
            fragColor = mix(fragColor, borderBandB, crystalMix * (0.35 + 0.50 * (1.0 - ring)));

            float glintDiagA = 1.0 - smoothstep(0.05, 0.16, abs(uvn11.x - uvn11.y));
            float glintDiagB = 1.0 - smoothstep(0.05, 0.16, abs(uvn11.x + uvn11.y));
            float glint = max(glintDiagA, glintDiagB) * (1.0 - ring);
            fragColor = mix(fragColor, vec4(205. / 255., 1.0, 214. / 255., 1.0), glint * 0.35);

            if (squareShape) {
                float corner = smoothstep(0.55, 0.90, abs(uvn11.x) * abs(uvn11.y));
                fragColor = mix(fragColor, vec4(12. / 255., 56. / 255., 34. / 255., 1.0), corner * 0.55);
            }
            if (ring > 0.82) {
                fragColor = mix(fragColor, vec4(6. / 255., 44. / 255., 25. / 255., 1.0), 0.65);
            }
        } else if (style == 4) {
            borderBase = vec4(30. / 255., 6. / 255., 10. / 255., 1.0);
            borderBandA = vec4(156. / 255., 28. / 255., 48. / 255., 1.0);
            borderBandB = vec4(245. / 255., 96. / 255., 122. / 255., 1.0);
            fragColor = mix(borderBase, borderBandA, ring);

            float sectors = 16.0;
            float sector = fract((angle + PI) / TAU * sectors);
            float facetEdge = min(sector, 1.0 - sector);
            float facet = 1.0 - smoothstep(0.08, 0.28, facetEdge);
            float radialFacet = 1.0 - smoothstep(0.30, 0.95, abs(uvn11.x * uvn11.y));
            float crystalMix = clamp(0.55 * facet + 0.65 * radialFacet, 0.0, 1.0);
            fragColor = mix(fragColor, borderBandB, crystalMix * (0.35 + 0.50 * (1.0 - ring)));

            float glintDiagA = 1.0 - smoothstep(0.05, 0.16, abs(uvn11.x - uvn11.y));
            float glintDiagB = 1.0 - smoothstep(0.05, 0.16, abs(uvn11.x + uvn11.y));
            float glint = max(glintDiagA, glintDiagB) * (1.0 - ring);
            fragColor = mix(fragColor, vec4(1.0, 182. / 255., 196. / 255., 1.0), glint * 0.35);

            if (squareShape) {
                float corner = smoothstep(0.55, 0.90, abs(uvn11.x) * abs(uvn11.y));
                fragColor = mix(fragColor, vec4(74. / 255., 8. / 255., 18. / 255., 1.0), corner * 0.55);
            }
            if (ring > 0.82) {
                fragColor = mix(fragColor, vec4(54. / 255., 6. / 255., 14. / 255., 1.0), 0.65);
            }
        } else if (style == 5) {
            borderBase = vec4(10. / 255., 10. / 255., 14. / 255., 1.0);
            borderBandA = vec4(46. / 255., 46. / 255., 58. / 255., 1.0);
            borderBandB = vec4(92. / 255., 92. / 255., 118. / 255., 1.0);
            fragColor = mix(borderBase, borderBandA, ring);
            float techLine = abs(fract((angle + PI) / TAU * 18.0) - 0.5);
            float pulse = 1.0 - smoothstep(0.42, 0.50, techLine);
            fragColor = mix(fragColor, borderBandB, pulse * (0.3 + 0.4 * (1.0 - ring)));
            if (squareShape) {
                float corner = smoothstep(0.60, 0.90, abs(uvn11.x) * abs(uvn11.y));
                fragColor = mix(fragColor, vec4(6. / 255., 6. / 255., 10. / 255., 1.0), corner * 0.5);
            }
        } else {
            fragColor = borderBase;
            if (ring > 0.35) {
                fragColor = borderBandA;
            }
            if (ring > 0.72) {
                fragColor = borderBandB;
            }
        }
        fragColor.a = 1.0;
    } else {
        discard;
    }
    if (minimap == 1.0) {
        fragColor.a = 1.0;
    } else {
        // Marker layers can have rotated/offset UVs. Do not use fract() here, it wraps negative UVs
        // and causes metadata bits to appear as moving gray dots near the right border.
        if (texCoord1.x < 0.0 || texCoord1.y < 0.0 || texCoord1.x >= 1.0 || texCoord1.y >= 1.0 ||
            (texCoord1.x < 17. / 128. && texCoord1.y < 3. / 128.) ||
            texCoord1.x <= 1. / 128. || texCoord1.x >= 127. / 128. || texCoord1.y >= 127. / 128.) {
            discard;
        }
    }
    if (fragColor.a < 0.1) {
        discard;
    }
    return;
} else if (minimap > 0.0) {
    discard;
}

if (fullscreenMinimap == 1.0) {
    ivec2 iuv = ivec2(texCoord0 * 128.);
    iuv.y = 127 - iuv.y;
    vec2 uv = texCoord0;
    uv.y *= 127. / 128.;
    uv.y += 1. / 128.;
    vec4 color = texture(Sampler0, uv);
    remapColor(color, colorProfile);
    float fsx = fract(sx);
    float fsy = fract(sy);
    if (fsx == 0 && fsy == 0) {
        if (sx == 1) iuv.y = 127 - iuv.y;
        if (sy == 1) iuv.x = 127 - iuv.x;
        if (iuv.x == 0 || iuv.y == 0) color = BORDER_COLOR1;
        else if (iuv.x == 1 || iuv.y == 1) color = BORDER_COLOR2;
        else if (iuv.x == 2 || iuv.y == 2) color = BORDER_COLOR1;
    } else if (fsx == 0 || fsy == 0) {
        int d = 0;
        if (fsx == 0) {
            if (sx == 1) iuv.y = 127 - iuv.y;
            d = iuv.y;
        } else {
            if (sy == 1) iuv.x = 127 - iuv.x;
            d = iuv.x;
        }
        if (d == 0) color = BORDER_COLOR1;
        else if (d == 1) color = BORDER_COLOR2;
        else if (d == 2) color = BORDER_COLOR1;
    }
    fragColor = color * vertexColor * ColorModulator;
    fragColor.a *= transition;
    return;
} else if (fullscreenMinimap == 2.0) {
    fragColor = vec4(0, 0, 0, 0.5 * transition);
    return;
}
